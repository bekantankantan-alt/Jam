plugins {
    id("com.android.application")
}

android {
    namespace = "id.hasim.ubahjamfoto"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.hasim.ubahjamfoto"
        minSdk = 23
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
