UBAH JAM FOTO — proyek Android pembungkus HTML

BUILD APK lewat GitHub:
1. Buat repository GitHub baru (misalnya ubah-jam-foto-apk).
2. Upload semua isi ZIP ini ke repository, bukan ZIP-nya sebagai satu file.
3. Pastikan folder .github/workflows ikut ter-upload.
4. Buka tab Actions, pilih "Build UBAH JAM FOTO APK", lalu klik Run workflow.
   (Build juga berjalan otomatis setelah push ke branch main.)
5. Tunggu workflow hijau selesai. Buka run tersebut, bagian Artifacts,
   lalu download UBAH-JAM-FOTO-APK.zip.
6. Ekstrak ZIP artifact untuk mengambil app-debug.apk, lalu install di HP.

Catatan:
- Ini APK debug untuk uji/install pribadi, bukan rilis Play Store.
- HTML V2 dimasukkan ke app/src/main/assets/index.html.
- Pemilihan foto melalui tombol HTML ditangani WebView file picker.
- Untuk update aplikasi yang sudah terpasang dari APK lama, Android bisa menolak
  instalasi karena signature atau applicationId berbeda. Jika begitu, uninstall
  APK lama dulu (pastikan data penting/cadangan aman), lalu install APK baru.
